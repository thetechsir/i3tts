# i3tts
 i3-kde eyecandy with polybar as well as kvm scripts
